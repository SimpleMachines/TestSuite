[center][size=14pt][b]Test Suite[/b][/size][/center]
[hr]
[color=blue][b]Summary:[/b][/color]
Allows a test suite to be built and used in testing
 
[color=blue][b]Compatibility:[/b][/color]
Compatible with SMF 2.0
 
[color=blue][b]Installation Information:[/b][/color]
The Package Manager should work in most cases, if you have problems installing please post in the developers board or pm Joker�


The icons/images/jackets contained in this archive are Copyright (c) The IconBlock Ltd. [url=http://www.iconblock.com]http://www.iconblock.com[/url] and are intended for personal and commercial use. By opening this electronic file you agree to be bound by the terms of this license. These files MAY NOT  SOLD OR EXCHANGED FOR ANY GOODS OR SERVICES WHATSOEVER.
 
Any registered trademarks remain the property of their respective holders. The IconBlock Ltd. shall not be held liable for any damages, whether direct, indirect, consequential or incidental, arising out of the use of, or the inability to use, this product or any individual icon/image.
